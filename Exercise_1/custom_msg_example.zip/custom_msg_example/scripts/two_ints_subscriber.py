#!/usr/bin/env python3
import rospy
from custom_msg_example.msg import TwoInts

def callback(msg):
    sum_result = msg.a + msg.b
    rospy.loginfo("Received: a = %d, b = %d, Sum = %d", msg.a, msg.b, sum_result)

def subscriber():
    rospy.init_node('two_ints_subscriber', anonymous=True)
    rospy.Subscriber('sum', TwoInts, callback)
    rospy.spin()

if __name__ == '__main__':
    subscriber()

